# Azure public HTTP flow validation — October 18, 2026

## Provenance

These are selected command-output excerpts and flow records supplied by the user
in the conversation, not commands executed by the report-writing agent.
The original capture, complete JSONL log and command outputs remain on the VM;
the binary capture has not been copied into this repository. Preserve/export
`~/firewall-flow-evidence/http-flow.pcap` and the complete outputs for submission.
No benchmark was rerun for this validation. This validates a current public flow,
not the exact historical October 17 deployment or the local container path.

## Attachment observations

Receiver kernel: `6.1.0-53-cloud-amd64`.

At `2026-10-18 09:24:44 UTC`, user-labelled Dual Map `t0-l1-full`:

```text
xdp:
eth0(2) driver id 564
tc:
eth0(2) clsact/egress tc_egress_prog:[566] id 566
```

`bpftool prog show` identified XDP 564 as `xdp_firewall_prog`, TC ingress 565
as `tc_ingress_prog` and TC egress 566 as `tc_egress_prog`. TC ingress was
loaded but not listed as attached. The profile label is user-supplied.

At `2026-10-18 09:26:03 UTC`, Dual Map `t1-l1-full`:

```text
xdp:
eth0(2) driver id 571
tc:
eth0(2) clsact/egress tc_egress_prog:[573] id 573
qdisc clsact ffff: parent ffff:fff1
filter protocol all pref 49152 bpf chain 0 handle 0x1 tc_egress_prog:[573] direct-action not_in_hw id 573 name tc_egress_prog tag b77a583f55af80e1 jited
```

Program 571: `xdp_firewall_prog`, tag `7afaafd8b9b70368`.
Program 572: `tc_ingress_prog`, loaded but not attached in the inventory.
Program 573: `tc_egress_prog`, tag `b77a583f55af80e1`.
All three shared map IDs `251,252,256,253,254,255`.
The later inventory still listed XDP 571 and TC egress 573.

Process inspection:

```text
1796495 sudo -n ./build/profiles/dualmap-t1-l1-full/fw-ctl -i eth0 -m hybrid -d both
1796496 sudo -n ./build/profiles/dualmap-t1-l1-full/fw-ctl -i eth0 -m hybrid -d both
1796497 ./build/profiles/dualmap-t1-l1-full/fw-ctl -i eth0 -m hybrid -d both
```

This records the launch path/options, not independent binary-build attestation.

## Interface and driver correlation

`ip -d link show` reported interface 2 `eth0`, VMBus-backed, and interface 3
`enP61709s1`, PCI-backed, `SLAVE`, `master eth0`; both had MAC
`00:0d:3a:81:0f:ad`. Interface 3 had alternate name `enP61709p0s2`.

`ethtool -i eth0`: driver `hv_netvsc`, version `6.1.0-53-cloud-amd64`.
`ethtool -i enP61709s1`: driver `mlx5_core`, same kernel version,
firmware `16.30.5034 (MSF0000000012)`, bus `f10d:00:02.0`.
This explains the observed synthetic/VF relationship: configured XDP attachment
on eth0, ingress event index 3, TC egress index 2. Do not invent a separately
listed XDP attachment on interface 3.

## Captured public HTTP connection

Local command:

```bash
curl -v --connect-timeout 2 --max-time 5 http://20.2.208.244:18080/
```

Curl reported local address `192.168.1.43:35728`, HTTP `200 OK`, and body
`firewall resilience test endpoint` (34 bytes).
Receiver capture excerpts, displayed with `tcpdump -nn -tttt -A -r`:

```text
2026-10-18 09:38:55.896460 IP 103.106.29.136.35728 > 172.16.0.4.18080: Flags [S], seq 2606886291, length 0
2026-10-18 09:38:55.896536 IP 172.16.0.4.18080 > 103.106.29.136.35728: Flags [S.], seq 960210986, ack 2606886292, length 0
2026-10-18 09:38:56.058987 IP 103.106.29.136.35728 > 172.16.0.4.18080: Flags [.], ack 1, length 0
2026-10-18 09:38:56.059038 IP 103.106.29.136.35728 > 172.16.0.4.18080: Flags [P.], seq 1:83, ack 1, length 82
GET / HTTP/1.1
Host: 20.2.208.244:18080
2026-10-18 09:38:56.059622 IP 172.16.0.4.18080 > 103.106.29.136.35728: Flags [P.], seq 1:186, ack 83, length 185
HTTP/1.0 200 OK
2026-10-18 09:38:56.059701 IP 172.16.0.4.18080 > 103.106.29.136.35728: Flags [FP.], seq 186:220, ack 83, length 34
firewall resilience test endpoint
2026-10-18 09:38:56.263729 IP 103.106.29.136.35728 > 172.16.0.4.18080: Flags [F.], seq 83, ack 221, length 0
2026-10-18 09:38:56.263769 IP 172.16.0.4.18080 > 103.106.29.136.35728: Flags [.], ack 84, length 0
```

Selected matching firewall JSONL records (verbatim):

```jsonl
{"type":"network","severity":"info","first_seen":"2026-10-18T09:38:55Z","last_seen":"2026-10-18T09:38:55Z","first_monotonic_ns":268896242804757,"last_monotonic_ns":268896242804757,"src_ip":"103.106.29.136","dst_ip":"172.16.0.4","src_port":35728,"dst_port":18080,"protocol":6,"direction":"in","ifindex":3,"action":"allow","reason":"policy","rule_id":5,"conn_state":2,"tcp_flags":2,"new_flow":true,"event_count":1,"observed_bytes":74}
{"type":"network","severity":"info","first_seen":"2026-10-18T09:38:55Z","last_seen":"2026-10-18T09:38:55Z","first_monotonic_ns":268896242890911,"last_monotonic_ns":268896242890911,"src_ip":"172.16.0.4","dst_ip":"103.106.29.136","src_port":18080,"dst_port":35728,"protocol":6,"direction":"out","ifindex":2,"action":"allow","reason":"state","rule_id":0,"conn_state":3,"tcp_flags":18,"new_flow":false,"event_count":1,"observed_bytes":74}
{"type":"network","severity":"info","first_seen":"2026-10-18T09:38:56Z","last_seen":"2026-10-18T09:38:56Z","first_monotonic_ns":268896406057114,"last_monotonic_ns":268896406057114,"src_ip":"172.16.0.4","dst_ip":"103.106.29.136","src_port":18080,"dst_port":35728,"protocol":6,"direction":"out","ifindex":2,"action":"allow","reason":"state","rule_id":0,"conn_state":5,"tcp_flags":25,"new_flow":false,"event_count":1,"observed_bytes":100}
{"type":"network","severity":"info","first_seen":"2026-10-18T09:38:56Z","last_seen":"2026-10-18T09:38:56Z","first_monotonic_ns":268896610082433,"last_monotonic_ns":268896610082433,"src_ip":"103.106.29.136","dst_ip":"172.16.0.4","src_port":35728,"dst_port":18080,"protocol":6,"direction":"in","ifindex":3,"action":"allow","reason":"state","rule_id":0,"conn_state":5,"tcp_flags":17,"new_flow":false,"event_count":1,"observed_bytes":66}
```

## Interpretation

The tuple, timestamps and TCP flags correlate captured opening/closing packets
with firewall events in both directions. This supports current flow-specific
firewall processing, consistent with the saved native-XDP/TC-egress architecture.
Events are selected transitions, not an exhaustive trace of every data packet.
Aggregate before/after counters were not used: SSH/background traffic confounds
them and no contemporaneous after snapshot was provided. No new latency,
throughput or security-resistance result is derived from this request.
